import { NextRequest, NextResponse } from 'next/server';

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const limit  = parseInt(searchParams.get('limit')  ?? '20');
  const offset = parseInt(searchParams.get('offset') ?? '0');
  const category = searchParams.get('category');
  const verdict  = searchParams.get('verdict');

  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    // Return mock history when Supabase is not configured
    return NextResponse.json({ data: MOCK_HISTORY, count: MOCK_HISTORY.length });
  }

  try {
    let url = `${SUPABASE_URL}/rest/v1/validations`
      + `?select=id,idea,category,market,cost,opportunity_score,trend_score,verdict,trend_stage,competition_level,confidence,created_at`
      + `&order=created_at.desc`
      + `&limit=${limit}&offset=${offset}`;

    if (category) url += `&category=eq.${encodeURIComponent(category)}`;
    if (verdict)  url += `&verdict=eq.${encodeURIComponent(verdict)}`;

    const res = await fetch(url, {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Prefer': 'count=exact',
      },
    });

    if (!res.ok) throw new Error(await res.text());

    const data  = await res.json();
    const count = parseInt(res.headers.get('content-range')?.split('/')[1] ?? '0');

    return NextResponse.json({ data, count });
  } catch (error) {
    console.error('[history] Error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch history' },
      { status: 500 }
    );
  }
}

// ── Mock fallback ──────────────────────────────────────────────
const MOCK_HISTORY = [
  {
    id: 'mock-1',
    idea: 'AI-powered sleep tracker ring for remote workers',
    category: 'Health & Wellness',
    market: 'United States',
    cost: 35,
    opportunity_score: 82,
    trend_score: 88,
    verdict: 'STRONG_BUY',
    trend_stage: 'RISING',
    competition_level: 'LOW',
    confidence: 0.87,
    created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
  },
  {
    id: 'mock-2',
    idea: 'B2B SaaS for remote team productivity analytics',
    category: 'B2B SaaS',
    market: 'Global',
    cost: 8,
    opportunity_score: 74,
    trend_score: 80,
    verdict: 'BUY',
    trend_stage: 'RISING',
    competition_level: 'MEDIUM',
    confidence: 0.81,
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
  },
  {
    id: 'mock-3',
    idea: 'Sustainable meal kit with zero-waste packaging',
    category: 'Food & Beverage',
    market: 'Europe',
    cost: 22,
    opportunity_score: 58,
    trend_score: 65,
    verdict: 'HOLD',
    trend_stage: 'SATURATED',
    competition_level: 'HIGH',
    confidence: 0.70,
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
  },
];
