'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Zap, ArrowLeft, Loader2 } from 'lucide-react';
import { ValidationForm } from '@/components/ValidationForm';
import { ResultsPanel } from '@/components/ResultsPanel';
import type { ValidationResult } from '@/lib/types';

export default function DashboardPage() {
  const [result, setResult] = useState<ValidationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleValidate(data: {
    idea: string;
    category: string;
    market: string;
    cost: number;
  }) {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch('/api/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Validation failed');
      }

      const json = await res.json();
      setResult(json);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#080810] text-white">
      {/* Nav */}
      <nav className="border-b border-white/5 backdrop-blur-xl bg-[#080810]/80 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="text-white/40 hover:text-white transition-colors">
              <ArrowLeft size={18} />
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-cyan-400 flex items-center justify-center">
                <Zap size={14} className="text-white" />
              </div>
              <span className="font-semibold tracking-tight text-sm">ProductIQ</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/history" className="text-xs text-white/30 hover:text-white transition-colors">History</Link>
            <span className="text-xs text-white/20">Product Validation Dashboard</span>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="mb-10">
          <h1 className="text-3xl font-black tracking-tighter mb-2">Validate your idea</h1>
          <p className="text-white/40 text-sm">Fill in the details below and our AI engine will score your product concept.</p>
        </div>

        <div className="grid lg:grid-cols-[420px_1fr] gap-8 items-start">
          {/* Form */}
          <div className="lg:sticky lg:top-24">
            <ValidationForm onSubmit={handleValidate} loading={loading} />
            {error && (
              <div className="mt-4 p-4 rounded-xl border border-red-500/20 bg-red-500/10 text-red-400 text-sm">
                {error}
              </div>
            )}
          </div>

          {/* Results */}
          <div>
            {loading && (
              <div className="flex flex-col items-center justify-center py-32 gap-4">
                <Loader2 size={32} className="text-violet-400 animate-spin" />
                <p className="text-white/40 text-sm">Running AI validation pipeline...</p>
                <div className="flex gap-2 text-xs text-white/20">
                  {['Generating embeddings', 'Scoring trends', 'Analyzing with AI'].map((s, i) => (
                    <span key={i} className="px-2 py-1 rounded-full border border-white/5 bg-white/[0.03]">{s}</span>
                  ))}
                </div>
              </div>
            )}
            {!loading && !result && (
              <div className="flex flex-col items-center justify-center py-32 text-center">
                <div className="w-20 h-20 rounded-2xl border border-white/5 bg-white/[0.03] flex items-center justify-center mb-5">
                  <Zap size={28} className="text-white/10" />
                </div>
                <p className="text-white/20 text-sm">Results will appear here</p>
              </div>
            )}
            {result && <ResultsPanel result={result} />}
          </div>
        </div>
      </div>
    </main>
  );
}
